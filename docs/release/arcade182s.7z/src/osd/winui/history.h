// license:BSD-3-Clause
// copyright-holders:Chris Kirmse, Mike Haaland, Ren� Single, Mamesick

#pragma once
 
#ifndef HISTORY_H
#define HISTORY_H

char * GetGameHistory(int driver_index);

#endif
