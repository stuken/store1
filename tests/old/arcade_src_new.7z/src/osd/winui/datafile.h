// license:BSD-3-Clause
// copyright-holders:Chris Kirmse, Mike Haaland, Ren� Single, Mamesick

#ifndef DATAFILE_H
#define DATAFILE_H

char * GetGameHistory(int driver_index);

#endif
